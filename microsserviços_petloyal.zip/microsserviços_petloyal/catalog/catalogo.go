package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"github.com/gorilla/mux"
)

type Catalogo struct {
	ID    int    `json:"id"`
	Nome  string `json:"nome"`
	Idade int    `json:"idade"`
	Raça  string `json:"raça"`
}

type Catalogos struct {
	Catalogo []Catalogo `json:"catalogo"` // Corrigido para corresponder à chave no JSON
}

func loadData() ([]Catalogo, error) {
	file, err := os.ReadFile("catalogos.json")
	if err != nil {
		return nil, err
	}

	var catalogos Catalogos
	err = json.Unmarshal(file, &catalogos)
	if err != nil {
		return nil, err
	}

	return catalogos.Catalogo, nil // Retorna a lista de Catalogo corretamente
}

func ListCatalogos(w http.ResponseWriter, r *http.Request) {
	catalogos, err := loadData()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// MarshalIndent gera uma saída JSON formatada e indentada para melhor legibilidade
	response, err := json.MarshalIndent(catalogos, "", "  ")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
}

func GetCatalogoById(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	catalogos, err := loadData()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	for _, v := range catalogos {
		if fmt.Sprintf("%d", v.ID) == vars["id"] { // Comparação com o ID convertido para string
			response, err := json.Marshal(v)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			w.Header().Set("Content-Type", "application/json")
			w.Write(response)
			return
		}
	}

	http.Error(w, "Product not found", http.StatusNotFound)
}

func main() {
	r := mux.NewRouter()
	r.HandleFunc("/catalogos", ListCatalogos).Methods("GET")
	r.HandleFunc("/catalogo/{id}", GetCatalogoById).Methods("GET")

	fmt.Println("Server is running on port 8081...")
	http.ListenAndServe(":8081", r)
}
